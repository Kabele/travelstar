<?php $attributes = $attributes->exceptProps(['route'=>$route,'title'=>$title]); ?>
<?php foreach (array_filter((['route'=>$route,'title'=>$title]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<!-- Delete Modal -->
<div class="modal custom-modal fade" id="delete_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-header">
                    <h3>Delete <?php echo e(ucfirst($title)); ?></h3>
                    <p>Are you sure want to delete?</p>
                </div>
                <form action="<?php echo e(route($route)); ?>" method="post">
                    <?php echo method_field("DELETE"); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="delete_id" name="id">
                    <div class="modal-btn delete-action">
                        <div class="row">
                            <div class="col-6">
                                <button class="btn btn-primary continue-btn btn-block" type="submit">Delete</button>
                            </div>
                            <div class="col-6">
                                <button data-dismiss="modal" class="btn btn-primary cancel-btn btn-block">Cancel</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Delete  Modal --><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/components/modals/delete.blade.php ENDPATH**/ ?>