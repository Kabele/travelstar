<?php $__env->startSection('styles'); ?>	
<!-- Datatable CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-header'); ?>
<div class="row align-items-center">
	<div class="col">
		<h3 class="page-title">Goal Type</h3>
		<ul class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
			<li class="breadcrumb-item active">Goal Type</li>
		</ul>
	</div>
	<div class="col-auto float-right ml-auto">
		<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_type"><i class="fa fa-plus"></i> Add New</a>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="table-responsive">
			<table class="table table-striped custom-table mb-0 datatable">
				<thead>
					<tr>
						<th>Type </th>
						<th>Description </th>
						<th class="text-right">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $goal_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($type->type); ?></td>
							<td><?php echo e($type->description); ?></td>
							
							<td class="text-right">
								<div class="dropdown dropdown-action">
									<a href="javascript:void(0)" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a data-id="<?php echo e($type->id); ?>" data-type="<?php echo e($type->type); ?>" data-description="<?php echo e($type->description); ?>" class="dropdown-item editbtn" href="javascript:void(0)" data-toggle="modal"><i class="fa fa-pencil m-r-5"></i> Edit</a>
										<a data-id="<?php echo e($type->id); ?>" class="dropdown-item deletebtn" href="javascript:void(0)" data-toggle="modal"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
									</div>
								</div>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
				</tbody>
			</table>
		</div>
	</div>
</div>

<!-- Add Goal Modal -->
<div id="add_type" class="modal custom-modal fade" role="dialog">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add New Goal Type</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form method="post" action="<?php echo e(route('goal-type')); ?>">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label>Goal Type <span class="text-danger">*</span></label>
						<input class="form-control" name="type" type="text">
					</div>
					<div class="form-group">
						<label>Description <span class="text-danger">*</span></label>
						<textarea name="description" class="form-control" rows="4"></textarea>
					</div>
					
					<div class="submit-section">
						<button class="btn btn-primary submit-btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- /Add Goal Modal -->

<!-- Edit Goal Modal -->
<div id="edit_type" class="modal custom-modal fade" role="dialog">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Goal Type</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form method="post" action="<?php echo e(route('goal-type')); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field("PUT"); ?>
					<input id="edit_id" type="hidden" name="id">
					<div class="form-group">
						<label>Goal Type <span class="text-danger">*</span></label>
						<input class="form-control edit_type" name="type" type="text" value="Invoice Goal">
					</div>
					<div class="form-group">
						<label>Description</label>
						<textarea class="form-control edit_description" name="description" rows="4"></textarea>
					</div>
					
					<div class="submit-section">
						<button class="btn btn-primary submit-btn">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- /Edit Goal Modal -->

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.delete','data' => ['route' => 'goal-type','title' => 'Goal Type']]); ?>
<?php $component->withName('modals.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('goal-type'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Goal Type')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('scripts'); ?>
	<!-- Datatable JS -->
	<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
	<script>
		$(document).ready(function (){
			$('.table').on('click','.editbtn',function (){
				$('#edit_type').modal('show');
				var id = $(this).data('id');
				var type = $(this).data('type');
				var description = $(this).data('description');
				$('#edit_id').val(id);
				$('.edit_type').val(type);
				$('.edit_description').val(description);
			});
		});
	</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/goal-type.blade.php ENDPATH**/ ?>