<?php $__env->startSection('content'); ?>
<?php if(session('login_error')): ?>
<div class="bg-danger p-3 rounded text-center mb-2 text-sm text-white">
    <?php echo e(session('login_error')); ?>

</div>
<?php endif; ?>
<form action="<?php echo e(route('login')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Email</label>
        <input name="email" type="text" value="<?php echo e(old('email') ?? 'admin@admin.com'); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    </div>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="bg-danger text-sm text-white p-3 rounded mb-2">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-group">
        <div class="row">
            <div class="col">
                <label>Password</label>
            </div>
            <div class="col-auto">
                <a class="text-muted" href="<?php echo e(route('forgot-password')); ?>">
                    Forgot password?
                </a>
            </div>
        </div>
        <input name="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="admin" type="password">
        
    </div>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="bg-danger text-sm text-white p-3 rounded mb-2">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-group text-center">
        <button class="btn btn-primary account-btn" type="submit">Login</button>
    </div>
    <div class="account-footer">
        <p>Don't have an account yet? <a href="<?php echo e(route('register')); ?>">Register</a></p>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/auth/login.blade.php ENDPATH**/ ?>