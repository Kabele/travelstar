<?php $__env->startSection('styles'); ?>	
<!-- Select2 CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/select2.min.css')); ?>">
<!-- Datatable CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
<!-- Summernote CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/dist/summernote-bs4.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<div class="row align-items-center">
	<div class="col">
		<h3 class="page-title">Invoices</h3>
		<ul class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
			<li class="breadcrumb-item active">Invoices</li>
		</ul>
	</div>
	<div class="col-auto float-right ml-auto">
		<a href="<?php echo e(route('invoices.create')); ?>" class="btn add-btn"><i class="fa fa-plus"></i> Create Invoice</a>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="table-responsive">
			<table class="table table-striped custom-table mb-0">
				<thead>
					<tr>
						<th>#</th>
						<th>Invoice Number</th>
						<th>Client</th>
						<th>Invoice Date</th>
						<th>Due Date</th>
						<th>Amount</th>
						<th>Status</th>
						<th class="text-end">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$count = 1;
					?>
					<?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($count); ?></td>
						<td><a href="<?php echo e(route('invoices.show',$invoice)); ?>"><?php echo e($invoice->inv_id); ?></a></td>
						<td><?php echo e($invoice->client->company); ?></td>
						<td><?php echo e(date_format(date_create($invoice->invoice_date),'d M, Y')); ?></td>
						<td><?php echo e(date_format(date_create($invoice->due_date),'d M, Y')); ?></td>
						<td><?php echo e(app(App\Settings\ThemeSettings::class)->currency_symbol.' '.$invoice->total); ?></td>
						<td><span class="badge bg-inverse-<?php echo e(($invoice->status == 'paid') ? 'success': 'danger'); ?>"><?php echo e(ucfirst($invoice->status)); ?></span></td>
						<td class="text-end">
							<div class="dropdown dropdown-action">
								<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item" href="<?php echo e(route('invoices.edit',$invoice->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
									<a class="dropdown-item" href="<?php echo e(route('invoices.show',$invoice)); ?>"><i class="fa fa-eye m-r-5"></i> View</a>
									<a class="dropdown-item deletebtn" href="javascript:void(0)" data-id="<?php echo e($invoice->id); ?>"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
								</div>
							</div>
						</td>
					</tr>
					<?php
						$count++;
					?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>   

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.delete','data' => ['route' => 'invoices.destroy','title' => 'Invoice']]); ?>
<?php $component->withName('modals.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'invoices.destroy','title' => 'Invoice']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Datatable JS -->
<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Select2 JS -->
<script src="<?php echo e(asset('assets/plugins/select2/select2.min.js')); ?>"></script>
<!-- summernote JS -->
<script src="<?php echo e(asset('assets/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/invoices/index.blade.php ENDPATH**/ ?>