<?php $__env->startSection('styles'); ?>
<!-- Select2 CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/select2.min.css')); ?>">
<!-- Datatable CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<div class="row align-items-center">
	<div class="col">
		<h3 class="page-title">Employee Attendance</h3>
		<ul class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
			<li class="breadcrumb-item active">Attendance</li>
		</ul>
	</div>
	<div class="col-auto float-right ml-auto">
		<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_attendance"><i class="fa fa-plus"></i> Add Modal</a>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="table-responsive">
			<table class="table datatable table-striped custom-table mb-0">
				<thead>
					<tr>
						<th>Employee</th>
						<th>TimeIn</th>
						<th>TimeOut</th>
						<th>Date</th>
						<th>Status</th>
						<th class="text-end">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<tr>
					   <td>
							<h2 class="table-avatar">
								<a href="#" class="avatar"><img alt="avatar"  src="<?php echo e(!empty($attendance->employee->avatar) ? asset('storage/employees/'.$attendance->employee->avatar): asset('assets/img/profiles/avatar-19.jpg')); ?>"></a>
								<a href="#"><?php echo e($attendance->employee->firstname.' '. $attendance->employee->lastname); ?><span><?php echo e($attendance->employee->designation->name); ?></span></a>
							</h2>
						</td>
					   <td><?php echo e(date_format(date_create($attendance->checkin),'H:i a')); ?></td>
					   <td><?php echo e(!empty($attendance->checkout) ? date_format(date_create($attendance->checkout),'H:i a'): ' '); ?></td>
					   <td><?php echo e(date_format(date_create($attendance->created_at),'d M, Y')); ?></td>
					   <td><?php echo e($attendance->status); ?></td>
					   <td class="text-end">
							<div class="dropdown dropdown-action">
								<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item editbtn" href="javascript:void(0)" data-id="<?php echo e($attendance->id); ?>" data-checkin="<?php echo e($attendance->checkin); ?>" data-checkout="<?php echo e($attendance->checkout); ?>" data-employee="<?php echo e($attendance->employee_id); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
									<a class="dropdown-item deletebtn" href="javascript:void(0)" data-id="<?php echo e($attendance->id); ?>"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
								</div>
							</div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.delete','data' => ['route' => 'employees.attendance','title' => 'Attendance']]); ?>
<?php $component->withName('modals.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'employees.attendance','title' => 'Attendance']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.popup','data' => []]); ?>
<?php $component->withName('modals.popup'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Select2 JS -->
<script src="<?php echo e(asset('assets/plugins/select2/select2.min.js')); ?>"></script>
<!-- Datatable JS -->
<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
	$(document).ready(function(){
		$('.editbtn').click(function(){
			var id = $(this).data('id');
			var checkin = $(this).data('checkin');
			var checkout = $(this).data('checkout');
			var employee = $(this).data('employee');
			$('#edit_attendance').modal('show');
			$('#edit_id').val(id);
			$('#edit_employee').val(employee).trigger('change');
			$('#edit_checkin').val(checkin);
			$('#edit_checkout').val(checkout);
		});
	});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/attendance.blade.php ENDPATH**/ ?>