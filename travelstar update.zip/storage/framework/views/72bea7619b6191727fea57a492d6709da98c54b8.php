<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="robots" content="noindex, nofollow">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(ucfirst(config('app.name'))); ?> - <?php echo e(ucfirst($title)); ?></title>
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(!empty(app(App\Settings\ThemeSettings::class)->favicon) ? asset('storage/settings/'.app(App\Settings\ThemeSettings::class)->favicon):asset('assets/img/favicon.png')); ?>">
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/line-awesome.min.css')); ?>">
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
		
		<!-- Toastr Css -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">
		<!-- Toastify css -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastify/src/toastify.css')); ?>">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
		<!-- Page Css -->
		<?php echo $__env->yieldContent('styles'); ?>

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php echo $__env->make('includes.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <?php echo $__env->make('includes.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
				<?php echo $__env->yieldContent('content_one'); ?>
				<!-- Page Content -->
                <div class="content container-fluid">
					
					<!-- Page Header -->
					<div class="page-header">
						<?php echo $__env->yieldContent('page-header'); ?>
					</div>
					<!-- /Page Header -->
					
					<?php if($errors->any()): ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<strong>Error!</strong> <?php echo e($error); ?>.
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
					<?php endif; ?>
					<?php if(session('success')): ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
						<strong>Success! </strong><?php echo e(session('success')); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<?php endif; ?>
					<!-- Content Starts -->
						<?php echo $__env->yieldContent('content'); ?>
					<!-- /Content End -->
					
                </div>
				<!-- /Page Content -->
				
            </div>
			<!-- /Page Wrapper -->
        </div>
		<!-- /Main Wrapper -->
		
		
    </body>
	<!-- jQuery -->
	<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
	<!-- Bootstrap Core JS -->
	<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
	<!-- Slimscroll JS -->
	<script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>
	<!-- Datetimepicker JS -->
	<script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>
	<!-- Ck Editor -->
	<script src="<?php echo e(asset('assets/plugins/ckeditor/ckeditor.js')); ?>"></script>
	<!-- Toastr JS -->
	<script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>
	<!-- Toastify JS -->
	<script src="<?php echo e(asset('assets/plugins/toastify/src/toastify.js')); ?>"></script>
	<!-- Custom JS -->
	<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
	<script>
		$(document).ready(function (){
			$('body').on('click','.deletebtn',function (){
				$('#delete_modal').modal('show');
				var id = $(this).data('id');
				$('#delete_id').val(id);
			});
			$('.alert').delay(2000).fadeOut();
            <?php if(Session::has('message')): ?>
                var type = "<?php echo e(Session::get('alert-type', '')); ?>";
                switch (type) {
                    case 'info':
                        toastr.info("<?php echo e(Session::get('message')); ?>");
                        break;
                    
                    case 'success':
                        toastr.success("<?php echo e(Session::get('message')); ?>");
                        break;
                    
                    case 'warning':
                        toastr.warning("<?php echo e(Session::get('message')); ?>");
                        break;
                    
                    case 'error':
                        toastr.error("<?php echo e(Session::get('message')); ?>");
                        break;
                    
                    case 'danger':
                        toastr.error("<?php echo e(Session::get('message')); ?>");
                        break;
                    
                }
            <?php endif; ?>
		});
	</script>
	<?php echo $__env->yieldContent('scripts'); ?>
</html><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/layouts/backend.blade.php ENDPATH**/ ?>