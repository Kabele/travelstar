<!-- Header -->
<div class="header">
			
    <!-- Logo -->
    <div class="header-left">
        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
            <img src="<?php echo e(!empty(app(App\Settings\ThemeSettings::class)->logo) ? asset('storage/settings/'.app(App\Settings\ThemeSettings::class)->logo):asset('assets/img/logo.png')); ?>" alt="logo" width="40" height="40">
        </a>
    </div>
    <!-- /Logo -->
    
    <a id="toggle_btn" href="javascript:void(0);">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>
    
    <!-- Header Title -->
    <div class="page-title-box">
        <h3><?php echo e(ucwords(app(App\Settings\CompanySettings::class)->company_name ?? 'Travelstar HRM')); ?></h3>
    </div>
    <!-- /Header Title -->
    
    <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
    
    <!-- Header Menu -->
    <ul class="nav user-menu">
    
        <!-- Notifications -->
        <li class="nav-item dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i> <span class="badge badge-pill"><?php echo e(auth()->user()->notifications->count()); ?></span>
            </a>
            <div class="dropdown-menu notifications">
                <div class="topnav-dropdown-header">
                    <span class="notification-title">Notifications</span>
                    <a href="<?php echo e(route('clear-all')); ?>" class="clear-noti"> Clear All </a>
                </div>
                <div class="noti-content">
                    <ul class="notification-list">
                        <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="notification-message">
                                <a href="<?php echo e(route('activity')); ?>">
                                    <div class="media">
                                        <span class="avatar">
                                            <img alt="user" src="<?php echo e(asset('storage/users/'.auth()->user()->avatar)); ?>">
                                        </span>
                                        <div class="media-body">
                                            <p class="noti-details"><span class="noti-title"><?php echo e(auth()->user()->name); ?></span> <?php echo e($notification->type); ?>

                                                 <span class="noti-title">This is the notification body</span></p>
                                            <p class="noti-time"><span class="notification-time"><?php echo e($notification->created_at->diffForHumans()); ?></span></p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="topnav-dropdown-footer">
                    <a href="<?php echo e(route('activity')); ?>">View all Notifications</a>
                </div>
            </div>
        </li>
        <!-- /Notifications -->
        
        

        <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <span class="user-img"><img src="<?php echo e(!empty(auth()->user()->avatar) ? asset('storage/users/'.auth()->user()->avatar) : asset('assets/img/user.jpg')); ?>" alt="user">
                <span class="status online"></span></span>
                <span><?php echo e(auth()->user()->username); ?></span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">My Profile</a>
                <a class="dropdown-item" href="<?php echo e(route('settings.theme')); ?>">Settings</a>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item">Logout</button>
                </form>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->
    
    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">My Profile</a>
            <a class="dropdown-item" href="<?php echo e(route('settings.theme')); ?>">Settings</a>
            <form action="<?php echo e(route('logout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="dropdown-item">Logout</button>
            </form>
        </div>
    </div>
    <!-- /Mobile Menu -->
    
</div>
<!-- /Header --><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/includes/backend/header.blade.php ENDPATH**/ ?>