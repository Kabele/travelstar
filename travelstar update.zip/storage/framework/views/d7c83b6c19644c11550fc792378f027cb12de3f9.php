<?php $__env->startSection('styles'); ?>
    <!-- Select2 css -->
    <link href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
    
        <!-- Page Header -->
        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="page-title">Company Settings</h3>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        
        <form action="<?php echo e(route('settings.company')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Company Name <span class="text-danger">*</span></label>
                        <input class="form-control" name="company_name" type="text" value="<?php echo e($settings->company_name); ?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Contact Person</label>
                        <input class="form-control" name="contact_person" value="<?php echo e($settings->contact_person); ?>" type="text">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Address</label>
                        <input class="form-control" name="address" value="<?php echo e($settings->address); ?>" type="text">
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <div class="form-group">
                        <label>Country</label>
                        <input type="text" name="country" value="<?php echo e($settings->country); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <div class="form-group">
                        <label>City</label>
                        <input class="form-control" name="city" value="<?php echo e($settings->city); ?>" type="text">
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <div class="form-group">
                        <label>State/Province</label>
                        <input type="text" name="province" value="<?php echo e($settings->province); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <div class="form-group">
                        <label>Postal Code</label>
                        <input class="form-control" name="postal_code" value="<?php echo e($settings->postal_code); ?>" type="text">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Email</label>
                        <input class="form-control" name="email" value="<?php echo e($settings->email); ?>" type="email">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input class="form-control" name="phone" value="<?php echo e($settings->phone); ?>" type="text">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Mobile Number</label>
                        <input class="form-control" name="mobile" value="<?php echo e($settings->mobile); ?>" type="text">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Fax</label>
                        <input class="form-control" name="fax" value="<?php echo e($settings->fax); ?>" type="text">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Website Url</label>
                        <input class="form-control" name="website_url" value="<?php echo e($settings->website_url); ?>" type="text">
                    </div>
                </div>
            </div>
            <div class="submit-section">
                <button type="submit" class="btn btn-primary submit-btn">Save</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Select2 JS -->
<script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/select2.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/settings/company.blade.php ENDPATH**/ ?>