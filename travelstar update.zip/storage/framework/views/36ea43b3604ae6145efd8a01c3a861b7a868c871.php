<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">
                    <span>Main</span>
                </li>
                <li class="<?php echo e(route_is('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>"><i class="la la-dashboard"></i> <span> Dashboard</span></a>
                </li>
                <!-- <li class="submenu">
                    <a href="#"><i class="la la-cube"></i> <span> Apps</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        
                        <li><a class="<?php echo e(route_is('contacts') ? 'active' : ''); ?>" href="<?php echo e(route('contacts')); ?>">Contacts</a></li>
                    </ul>
                </li> -->
                <li class="menu-title">
                    <span>Employees</span>
                </li>
                <li class="submenu">
                    <a href="#" class="<?php echo e(route_is(['employees','employees-list']) ? 'active' : ''); ?> noti-dot"><i class="la la-user"></i> <span> Employees</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a class="<?php echo e(route_is('employees') ? 'active' : ''); ?>" href="<?php echo e(route('employees')); ?>">All Employees</a></li>
                        <li><a class="<?php echo e(route_is('holidays') ? 'active' : ''); ?>" href="<?php echo e(route('holidays')); ?>">Holidays</a></li>
                        <li><a class="<?php echo e(route_is('employees.attendance') ? 'active' : ''); ?>" href="<?php echo e(route('employees.attendance')); ?>">Attendance</a></li>
                        <li><a class="<?php echo e(route_is('leave-type') ? 'active' : ''); ?>" href="<?php echo e(route('leave-type')); ?>">Leave Type</a></li>
                        <li><a class="<?php echo e(route_is('employee-leave') ? 'active' : ''); ?>" href="<?php echo e(route('employee-leave')); ?>">Leaves (Employee)</a></li>
                        <li><a class="<?php echo e(route_is('departments') ? 'active' : ''); ?>" href="<?php echo e(route('departments')); ?>">Departments</a></li>
                        <li><a class="<?php echo e(route_is('designations') ? 'active' : ''); ?>" href="<?php echo e(route('designations')); ?>">Designations</a></li>
                        <li><a class="<?php echo e(route_is('overtime') ? 'active' : ''); ?>" href="<?php echo e(route('overtime')); ?>">Overtime</a></li>
                    </ul>
                </li>
                
                <li class="<?php echo e(route_is('clients') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('clients')); ?>"><i class="la la-users"></i> <span>Clients</span></a>
                </li>

                <!-- <li class="submenu">
                    <a href="#"><i class="la la-rocket"></i> <span> Projects </span> <span class="menu-arrow"></span></a>
                    <ul style="display: non;">
                        <li>
                            <a class="<?php echo e(route_is(['projects','project-list']) ? 'active' : ''); ?>" href="<?php echo e(route('projects')); ?>">Projects</a>
                        </li>
                    </ul>
                </li> -->
                
                <li class="<?php echo e(route_is('leads') ? 'active' : ''); ?>"> 
                    <a href="<?php echo e(route('leads')); ?>"><i class="la la-user-secret"></i> <span>Leads</span></a>
                </li>

                <li class="<?php echo e(route_is('tickets') ? 'active' : ''); ?>"> 
                    <a href="<?php echo e(route('tickets')); ?>"><i class="la la-ticket"></i> <span>Tickets</span></a>
                </li>

                <li class="menu-title"> 
                    <span>HR</span>
                </li>
                <li class="submenu">
                    <a href="#"><i class="la la-files-o"></i> <span> Accounts </span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a class="<?php echo e(route_is('invoices.*') ? 'active' : ''); ?>" href="<?php echo e(route('invoices.index')); ?>">Invoices</a></li>
                        <li><a class="<?php echo e(route_is('expenses') ? 'active' : ''); ?>" href="<?php echo e(route('expenses')); ?>">Expenses</a></li>
                        <li><a class="<?php echo e(route_is('provident-fund') ? 'active' : ''); ?>" href="<?php echo e(route('provident-fund')); ?>">Provident Fund</a></li>
                        <li><a class="<?php echo e(route_is('taxes') ? 'active' : ''); ?>" href="<?php echo e(route('taxes')); ?>">Taxes</a></li>
                    </ul>
                </li>
                
                <li class="<?php echo e(route_is('policies') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('policies')); ?>"><i class="la la-file-pdf-o"></i> <span>Policies</span></a>
                </li>
                
                <li class="submenu">
                    <a href="#"><i class="la la-briefcase"></i> <span> Jobs </span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a class="<?php echo e(route_is('jobs') ? 'active' : ''); ?>" href="<?php echo e(route('jobs')); ?>"> Manage Jobs </a></li>
                        <li><a class="<?php echo e(route_is('job-applicants') ? 'active' : ''); ?>" href="<?php echo e(route('job-applicants')); ?>"> Applied Candidates </a></li>
                    </ul>
                </li>
                <li class="submenu">
                    <a href="#"><i class="la la-crosshairs"></i> <span> Goals </span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a class="<?php echo e(route_is('goal-tracking') ? 'active' : ''); ?>" href="<?php echo e(route('goal-tracking')); ?>"> Goal List </a></li>
                        <li><a class="<?php echo e(route_is('goal-type') ? 'active' : ''); ?>" href="<?php echo e(route('goal-type')); ?>"> Goal Type </a></li>
                    </ul>
                </li>
                <li class="<?php echo e(route_is('assets') ? 'active' : ''); ?>"> 
                    <a href="<?php echo e(route('assets')); ?>"><i class="la la-object-ungroup"></i> <span>Assets</span></a>
                </li>
                <li>
                    <a class="<?php echo e(route_is('activity') ? 'active' : ''); ?>" href="<?php echo e(route('activity')); ?>"><i class="la la-bell"></i> <span>Activities</span></a>
                </li>
                <li class="<?php echo e(route_is('users') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('users')); ?>"><i class="la la-user-plus"></i> <span>Users</span></a>
                </li>
              
                <li>
                    <a class="<?php echo e(route_is('settings.theme') ? 'active' : ''); ?>" href="<?php echo e(route('settings.theme')); ?>"><i class="la la-cog"></i> <span>Settings</span></a>
                </li>
                <li class="<?php echo e(Request::is('backups') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('backups')); ?>"
                        ><i class="la la-cloud-upload"></i> <span>Backups </span>
                    </a>
                </li>
                
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/includes/backend/sidebar.blade.php ENDPATH**/ ?>