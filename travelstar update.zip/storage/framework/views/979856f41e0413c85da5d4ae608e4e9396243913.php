<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('vendor/laravel_backup_panel/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendor/laravel_backup_panel/app.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastify/src/toastify.css')); ?>">
<?php echo \Livewire\Livewire::styles(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laravel_backup_panel::app', [])->html();
} elseif ($_instance->childHasBeenRendered('VdPb2sk')) {
    $componentId = $_instance->getRenderedChildComponentId('VdPb2sk');
    $componentTag = $_instance->getRenderedChildComponentTagName('VdPb2sk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VdPb2sk');
} else {
    $response = \Livewire\Livewire::mount('laravel_backup_panel::app', []);
    $html = $response->html();
    $_instance->logRenderedChild('VdPb2sk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/plugins/toastify/src/toastify.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/backups/index.blade.php ENDPATH**/ ?>