<?php $__env->startSection('styles'); ?>	
<!-- Datatable CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<div class="row align-items-center">
	<div class="col">
		<h3 class="page-title">Assets</h3>
		<ul class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
			<li class="breadcrumb-item active">Assets</li>
		</ul>
	</div>
	<div class="col-auto float-right ml-auto">
		<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_asset"><i class="fa fa-plus"></i> Add Asset</a>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="table-responsive">
			<table class="table table-striped custom-table mb-0 datatable">
				<thead>
					<tr>
						<th>Asset Name</th>
						<th>Asset Id</th>
						<th>Purchase Date</th>
						<th>Warrenty</th>
						<th>Supplier</th>
						<th>Amount</th>
						<th class="text-center">Status</th>
						<th class="text-right"></th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>
								<strong><?php echo e($asset->name); ?></strong>
							</td>
							<td><?php echo e($asset->uuid); ?></td>
							<td><?php echo e(date_format(date_create($asset->purchase_date),'D M,Y')); ?></td>
							<td><?php echo e($asset->warranty); ?> Months</td>
							<td><?php echo e($asset->supplier); ?></td>
							<td><?php echo e(AppSettings::get('currency','$')); ?> <?php echo e($asset->value); ?></td>
							<td class="text-center">
								<i class="fa fa-dot-circle-o <?php if($asset->status == 'Approved'): ?>text-success <?php elseif($asset->status == 'Pending'): ?> text-danger <?php elseif($asset->status == 'Returned'): ?> text-info <?php endif; ?>"></i> <?php echo e($asset->status); ?>

							</td>
							<td class="text-right">
								<div class="dropdown dropdown-action">
									<a href="javascript:void(0)" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a data-id="<?php echo e($asset->id); ?>" data-name="<?php echo e($asset->name); ?>" 
											data-uuid="<?php echo e($asset->uuid); ?>" data-pdate="<?php echo e($asset->purchase_date); ?>"
											 data-pfrom="<?php echo e($asset->purchase_from); ?>" 
											 data-manufacturer="<?php echo e($asset->manufacturer); ?>"
											 data-model="<?php echo e($asset->model); ?>" data-sn="<?php echo e($asset->serial_number); ?>" data-supplier="<?php echo e($asset->supplier); ?>" data-condition="<?php echo e($asset->condition); ?>" data-warranty="<?php echo e($asset->warranty); ?>" data-value="<?php echo e($asset->value); ?>"
											 data-status="<?php echo e($asset->status); ?>" data-description="<?php echo e($asset->description); ?>" class="dropdown-item editbtn" href="javascript:void(0)" data-toggle="modal"><i class="fa fa-pencil m-r-5"></i> Edit</a>
										<a data-id="<?php echo e($asset->id); ?>" class="dropdown-item deletebtn" href="javascript:void(0)" data-toggle="modal"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
									</div>
								</div>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
				</tbody>
			</table>
		</div>
	</div>
</div>
<!-- Add Asset Modal -->
<div id="add_asset" class="modal custom-modal fade" role="dialog">
	<div class="modal-dialog modal-md" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add Asset</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form method="post" action="<?php echo e(route('assets')); ?>">
					<?php echo csrf_field(); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Asset Name</label>
								<input class="form-control" name="name" type="text">
							</div>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Purchase Date</label>
								<input class="form-control datetimepicker" name="purchase_date" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Purchase From</label>
								<input class="form-control" name="purchase_from" type="text">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Manufacturer</label>
								<input class="form-control" name="manufacturer" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Model</label>
								<input class="form-control" name="model" type="text">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Serial Number</label>
								<input class="form-control" name="serial_number" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Supplier</label>
								<input class="form-control" name="supplier" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Condition</label>
								<input class="form-control" name="condition" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Warranty</label>
								<input class="form-control" name="warranty" type="text" placeholder="In Months">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Value</label>
								<input name="value" placeholder="1800" class="form-control" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Status</label>
								<select name="status" class="select">
									<option>Approved</option>
									<option>Pending</option>
									<option>Returned</option>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Description</label>
								<textarea name="description" class="form-control"></textarea>
							</div>
						</div>
					</div>
					<div class="submit-section">
						<button class="btn btn-primary submit-btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- /Add Asset Modal -->

<!-- Edit Asset Modal -->
<div id="edit_asset" class="modal custom-modal fade" role="dialog">
	<div class="modal-dialog modal-md" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Asset</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form method="post" action="<?php echo e(route('assets')); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field("PUT"); ?>
					<div class="row">
						<input type="hidden" name="id" id="edit_id">
						<div class="col-md-6">
							<div class="form-group">
								<label>Asset Name</label>
								<input class="form-control edit_name" name="name" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Asset Id</label>
								<input name="uuid" class="form-control edit_uuid" type="text" value="#AST-0001" readonly>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Purchase Date</label>
								<input class="form-control datetimepicker edit_date" name="purchase_date" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Purchase From</label>
								<input class="form-control edit_from" name="purchase_from" type="text">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Manufacturer</label>
								<input class="form-control edit_manufacturer" name="manufacturer" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Model</label>
								<input class="form-control edit_model" name="model" type="text">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Serial Number</label>
								<input class="form-control edit_serial" name="serial_number" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Supplier</label>
								<input class="form-control edit_supplier" name="supplier" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Condition</label>
								<input class="form-control edit_condition" name="condition" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Warranty</label>
								<input class="form-control edit_warranty" name="warranty" type="text" placeholder="In Months">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Value</label>
								<input name="value" placeholder="1800" class="form-control edit_value" type="text">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Status</label>
								<select name="status" class="select" id="status_select" selected="selected">
									<option>Pending</option>
									<option>Approved</option>
									<option>Returned</option>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Description</label>
								<textarea name="description" class="form-control edit_description"></textarea>
							</div>
						</div>
					</div>
					<div class="submit-section">
						<button class="btn btn-primary submit-btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Edit Asset Modal -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.delete','data' => ['route' => 'assets','title' => 'Asset']]); ?>
<?php $component->withName('modals.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('assets'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Asset')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<!-- Datatable JS -->
	<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
	<script>
		$(document).ready(function(){
			$('.table').on('click','.editbtn',function(){
				$('#edit_asset').modal('show');
				var id = $(this).data('id');
				var uuid = $(this).data('uuid');
				var name = $(this).data('name');
				var purchase_date = $(this).data('pdate');
				var purchase_from = $(this).data('pfrom');
				var manufacturer = $(this).data('manufacturer');
				var serial_number = $(this).data('sn');
				var model = $(this).data('model');
				var supplier = $(this).data('supplier');
				var condition = $(this).data('condition');
				var warranty = $(this).data('warranty');
				var value = $(this).data('value');
				var status = $(this).data('status');
				var description = $(this).data('description');
				$('#edit_id').val(id);
				$('.edit_name').val(name);
				$('.edit_uuid').val(uuid);
				$('.edit_date').val(purchase_date);
				$('.edit_from').val(purchase_from);
				$('.edit_manufacturer').val(manufacturer);
				$('.edit_model').val(model);
				$('.edit_serial').val(serial_number);
				$('.edit_supplier').val(supplier);
				$('.edit_condition').val(condition);
				$('.edit_warranty').val(warranty);
				$('.edit_value').val(value);
				$("#status_select").val(status).change();
				$('.edit_description').val(description);
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/assets.blade.php ENDPATH**/ ?>