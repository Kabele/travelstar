<?php $__env->startSection('styles'); ?>	
<!-- Datatable CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-header'); ?>
<div class="page-header">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="page-title">Job Applicants</h3>
			<ul class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
				<li class="breadcrumb-item active">Job Applicants</li>
			</ul>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>	


<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="table-responsive">
			<table class="table table-striped custom-table mb-0 datatable">
				<thead>
					<tr>
						<th>Position</th>
						<th>Name</th>
						<th>Email</th>
						<th>Apply Date</th>
						<th class="text-center">Status</th>
						<th>Resume</th>
						<th class="text-right">Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
						<tr>
							<td><?php echo e($applicant->Job->title); ?></td>
							<td><?php echo e($applicant->name); ?></td>
							<td><?php echo e($applicant->email); ?></td>
							<td><?php echo e($applicant->created_at->diffForHumans()); ?></td>
							<td class="text-center">
								<div class="dropdown action-label">
									<a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
										<i class="fa fa-dot-circle-o text-info"></i> New
									</a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> New</a>
										<a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-success"></i> Hired</a>
										<a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-danger"></i> Rejected</a>
										<a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-danger"></i> Interviewed</a>
									</div>
								</div>
							</td>
							<td>
								<form action="<?php echo e(route('download-cv')); ?>" method="post">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="cv" value="<?php echo e($applicant->cv); ?>">
									<button class="btn btn-sm btn-primary" type="submit">
										<i class="fa fa-download"></i>
										 Download
									</button>	
									
								</form>
							</td>
							<td class="text-right">
								<div class="dropdown dropdown-action">
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#"><i class="fa fa-clock-o m-r-5"></i> Schedule Interview</a>
									</div>
								</div>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
	<!-- Datatable JS -->
	<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/job-applicants.blade.php ENDPATH**/ ?>