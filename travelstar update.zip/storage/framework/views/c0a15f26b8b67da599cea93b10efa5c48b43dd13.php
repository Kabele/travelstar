<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!empty($job->department)): ?>
    <div class="col-md-6">
        <a class="job-list" href="<?php echo e(route('job-view',$job)); ?>">
            <div class="job-list-det">
                <div class="job-list-desc">
                    <h3 class="job-list-title"><?php echo e($job->title); ?></h3>
                    <h4 class="job-department"><?php echo e($job->department->name); ?></h4>
                </div>
                <div class="job-type-info">
                    <span class="job-types"><?php echo e($job->type); ?></span>
                </div>
            </div>
            <div class="job-list-footer">
                <ul>
                    <li><i class="fa fa-map-signs"></i> California</li>
                    <li><i class="fa fa-money"></i> $<?php echo e($job->salary_from); ?>-$<?php echo e($job->salary_to); ?></li>
                    <li><i class="fa fa-clock-o"></i> <?php echo e($job->created_at->diffForHumans()); ?></li>
                </ul>
            </div>
        </a>
    </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/frontend/job-list.blade.php ENDPATH**/ ?>