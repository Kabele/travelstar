<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
    
        <!-- Page Header -->
        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="page-title">Invoice Settings</h3>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        
        <form action="<?php echo e(route('settings.invoice')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-lg-3 col-form-label">Invoice prefix</label>
                <div class="col-lg-9">
                    <input type="text" value="<?php echo e($settings->prefix); ?>"name="prefix" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-3 col-form-label">Invoice Logo</label>
                <div class="col-lg-7">
                    <input type="file" value="<?php echo e($settings->logo); ?>" class="form-control" name="logo">
                    <span class="form-text text-muted">Recommended image size is 200px x 40px</span>
                </div>
                <div class="col-lg-2">
                    <div class="img-thumbnail float-end"><img  src="<?php echo e((!empty($settings->logo) && $settings->logo != ' ') ? asset('storage/settings/invoice/'.$settings->logo): asset('assets/img/logo3.png')); ?>" class="img-fluid" alt="logo" width="140" height="40"></div>
                </div>
            </div>
            <div class="submit-section">
                <button type="submit" class="btn btn-primary submit-btn">Save</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend-settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bonwicliff/Documents/Company/projects/Laravel-Smarthr/resources/views/backend/settings/invoice.blade.php ENDPATH**/ ?>