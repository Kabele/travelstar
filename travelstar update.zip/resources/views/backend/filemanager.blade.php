@extends('layouts.backend')

@section('styles')

@endsection

@section('page-header')

@endsection

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <iframe src="/filemanager" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
        </div>
    </div>
@endsection

@section('scripts')

@endsection
